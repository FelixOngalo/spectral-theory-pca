# From the Spectral Theorem to PCA

**Question:** *(fill in)* Why does PCA's standard recipe ("eigendecompose the covariance matrix") actually work, and why is it provably the *best possible* way to summarize data in fewer dimensions — not just a reasonable one?

**Key findings:** *(fill in after rendering; did the from-scratch eigendecomposition match base R to numerical precision, and did the rank-k reconstruction error exactly hit the Eckart-Young theoretical bound at every k?)*

**Tools:** R (base linear algebra only — no `eigen()`/`prcomp()` used in the core implementation, only for cross-checking), Quarto report with LaTeX theorem statements and proofs

## Why this project exists

This is the first in a planned series of projects pairing a **pure mathematics topic** (a theorem, stated and proved properly) with a **from-scratch implementation and numerical verification** in R — built to demonstrate mathematical maturity (not just coding ability) for graduate study in pure mathematics, while staying connected to the applied/data-analysis side of this portfolio. This one covers three results from linear algebra that together justify PCA end to end.

## Reproduce

1. `install.packages(c("tidyverse", "scales"))`
2. Run `R/01_verify_theory.R` — simulates correlated data, runs the from-scratch PCA, and checks it against base R
3. Render `reports/report.qmd` for the full theorem statements, proofs, and verification plots

## Theorems covered

| Theorem | What it guarantees | Why PCA needs it |
|---|---|---|
| **Spectral theorem** | A real symmetric matrix has real eigenvalues and an orthonormal eigenbasis | Guarantees the covariance matrix's eigendecomposition *exists* at all, with real, orthogonal directions |
| **Rayleigh quotient bound** | $R(x) = x^\top Ax / x^\top x$ is always between $A$'s smallest and largest eigenvalue, with equality exactly at the eigenvectors | Proves the top eigenvector is *exactly* the direction of maximum variance, not just a convenient choice |
| **Eckart-Young theorem** | The rank-k truncated SVD is the best possible rank-k approximation to a matrix in Frobenius norm, among *all* rank-k matrices | Proves PCA's rank-k reconstruction is provably optimal, not merely a lot of variance captured |

## Method in brief

1. Simulate data with a known shared-factor structure (two underlying factors + one independent noise variable), so there's genuine, non-trivial structure for PCA to recover.
2. Implement eigendecomposition from scratch via **power iteration + deflation** — directly tied to the spectral theorem's constructive proof.
3. Cross-check every eigenvalue/eigenvector against base R's `eigen()` and `prcomp()`.
4. Verify the Rayleigh quotient bound by sampling thousands of random directions and confirming none fall outside $[\lambda_{\min}, \lambda_{\max}]$.
5. Verify the Eckart-Young theorem by comparing the actual rank-k reconstruction error against the theoretical bound, at several values of k.

## Project structure

```
R/linalg_functions.R      rayleigh_quotient, power_iteration, eigendecompose_by_deflation,
                           pca_from_scratch, reconstruct_rank_k, eckart_young_bound
R/01_verify_theory.R      simulate data, run + cross-check the from-scratch implementation
reports/report.qmd        theorem statements, proof sketches, and numerical verification
```

## Limitations

- Power iteration + deflation is a teaching implementation — slower and less numerically stable than the QR-algorithm routines LAPACK actually uses.
- Proofs are sketches conveying the key ideas, not textbook-complete rigorous proofs.
- Only tested on one simulated dataset with well-separated eigenvalues — power iteration can struggle when eigenvalues are close in magnitude, an edge case not explored here.
- *(add your own)*
