# From-scratch implementations of the linear-algebra machinery behind
# PCA, built directly from the theorems this project is about rather
# than calling R's built-in eigen()/prcomp() and taking them on faith.
# The point of this file is to make the connection between the THEOREMS
# (stated and proved in reports/report.qmd) and the ALGORITHM explicit:
# every function here corresponds to a specific step a proof justifies.

#' Rayleigh quotient: R(x) = (x'Ax) / (x'x), for a symmetric matrix A
#' and nonzero vector x. For a symmetric A, the spectral theorem
#' guarantees R(x) is always a weighted average of A's eigenvalues (the
#' weights depending on x's direction relative to A's eigenvectors) --
#' which is exactly why R(x) is bounded between A's smallest and
#' largest eigenvalues for EVERY x, with equality only at the
#' corresponding eigenvectors. This function is used in the report to
#' check that bound numerically.
#'
#' @param A A symmetric matrix.
#' @param x A nonzero vector of matching dimension.
#' @return A single number, the Rayleigh quotient.
rayleigh_quotient <- function(A, x) {
  as.numeric((t(x) %*% A %*% x) / (t(x) %*% x))
}

#' Find the dominant eigenpair (largest |eigenvalue|, with its
#' eigenvector) of a symmetric matrix via POWER ITERATION: repeatedly
#' apply A to a vector and renormalize. This works because any starting
#' vector can be written as a combination of A's eigenvectors, and
#' repeated multiplication by A scales the component along the
#' dominant eigenvector fastest relative to the others -- so after
#' enough iterations, that component dominates and the vector
#' converges (up to scale) to the dominant eigenvector. The eigenvalue
#' is then recovered as the converged vector's Rayleigh quotient.
#'
#' @param A A symmetric matrix.
#' @param max_iter Maximum number of iterations.
#' @param tol Convergence tolerance on successive eigenvalue estimates.
#' @return A list: value (the eigenvalue), vector (unit eigenvector),
#'   iterations (how many were used), converged (logical).
power_iteration <- function(A, max_iter = 1000, tol = 1e-10) {
  n <- nrow(A)
  x <- rnorm(n)
  x <- x / sqrt(sum(x^2))

  eigenvalue_prev <- Inf
  for (i in seq_len(max_iter)) {
    x_new <- A %*% x
    x_new <- x_new / sqrt(sum(x_new^2))
    eigenvalue <- rayleigh_quotient(A, x_new)

    if (abs(eigenvalue - eigenvalue_prev) < tol) {
      return(list(value = eigenvalue, vector = as.vector(x_new), iterations = i, converged = TRUE))
    }
    x <- x_new
    eigenvalue_prev <- eigenvalue
  }
  list(value = eigenvalue, vector = as.vector(x), iterations = max_iter, converged = FALSE)
}

#' Full eigendecomposition of a symmetric matrix via power iteration +
#' DEFLATION: find the dominant eigenpair, then "remove" it from A by
#' subtracting lambda_1 * v1 %*% t(v1), leaving a matrix whose dominant
#' eigenpair is now A's SECOND eigenpair (because the spectral theorem
#' guarantees A's eigenvectors are orthogonal, removing the v1
#' component this way doesn't disturb any of the others). Repeating
#' this k times recovers the top k eigenpairs in order.
#'
#' This is a teaching implementation, not a production one -- LAPACK's
#' QR-algorithm-based eigen() is faster and more numerically stable,
#' and is used throughout the report to check this function's answers.
#'
#' @param A A symmetric matrix.
#' @param k Number of top eigenpairs to extract (default: all of them).
#' @return A list: values (vector of eigenvalues, decreasing), vectors
#'   (matrix with eigenvectors as columns, same order).
eigendecompose_by_deflation <- function(A, k = nrow(A)) {
  n <- nrow(A)
  A_remaining <- A
  values  <- numeric(k)
  vectors <- matrix(0, n, k)

  for (i in seq_len(k)) {
    result <- power_iteration(A_remaining)
    values[i]    <- result$value
    vectors[, i] <- result$vector
    # Deflation: subtract this eigenpair's contribution so the NEXT
    # power iteration converges to the next-largest eigenpair instead
    # of finding the same one again.
    A_remaining <- A_remaining - result$value * (result$vector %*% t(result$vector))
  }
  list(values = values, vectors = vectors)
}

#' PCA from scratch: center the data, form the covariance matrix, and
#' eigendecompose it using eigendecompose_by_deflation() above. The
#' connection to the spectral theorem is direct: the covariance matrix
#' is symmetric (by construction, Cov = X'X / (n-1)), so the spectral
#' theorem guarantees it has a full set of real, orthogonal
#' eigenvectors -- those eigenvectors ARE the principal component
#' directions, and their eigenvalues ARE the variance explained along
#' each direction.
#'
#' @param X A numeric data matrix (observations x variables).
#' @param k Number of components to compute (default: all).
#' @return A list: center (column means used), eigenvalues,
#'   loadings (eigenvectors, variables x k), scores (X projected onto
#'   the components, observations x k), variance_explained (eigenvalue
#'   / sum of all eigenvalues, per component).
pca_from_scratch <- function(X, k = ncol(X)) {
  X <- as.matrix(X)
  center <- colMeans(X)
  X_centered <- scale(X, center = center, scale = FALSE)

  cov_matrix <- (t(X_centered) %*% X_centered) / (nrow(X) - 1)
  eigen_result <- eigendecompose_by_deflation(cov_matrix, k = k)

  scores <- X_centered %*% eigen_result$vectors

  list(
    center = center,
    eigenvalues = eigen_result$values,
    loadings = eigen_result$vectors,
    scores = scores,
    variance_explained = eigen_result$values / sum(diag(cov_matrix))
  )
}

#' Rank-k reconstruction of X from a PCA result, and its Frobenius-norm
#' reconstruction error -- used to numerically check the ECKART-YOUNG
#' THEOREM, which says the rank-k approximation built from the top k
#' singular vectors/principal components is the BEST possible rank-k
#' approximation to X in Frobenius norm, among ALL rank-k matrices (not
#' just ones built from PCA).
#'
#' @param X Original (centered) data matrix.
#' @param pca_result Output of pca_from_scratch(), computed with at
#'   least k components.
#' @param k Rank of the reconstruction.
#' @return A list: reconstruction (matrix), frobenius_error (number).
reconstruct_rank_k <- function(X_centered, pca_result, k) {
  scores_k   <- pca_result$scores[, seq_len(k), drop = FALSE]
  loadings_k <- pca_result$loadings[, seq_len(k), drop = FALSE]
  reconstruction <- scores_k %*% t(loadings_k)

  frobenius_error <- sqrt(sum((X_centered - reconstruction)^2))

  list(reconstruction = reconstruction, frobenius_error = frobenius_error)
}

#' The Eckart-Young THEORETICAL lower bound on rank-k reconstruction
#' error: sqrt(sum of the squares of all eigenvalues/singular-value^2
#' terms EXCLUDING the top k) -- i.e. the Frobenius-norm "mass" left
#' over in the directions a rank-k approximation can't capture. No
#' rank-k matrix can do better than this, by the theorem; this function
#' computes that bound so the report can confirm reconstruct_rank_k()
#' actually achieves it (up to numerical tolerance).
#'
#' @param eigenvalues Eigenvalues of the covariance matrix, decreasing.
#' @param n_obs Number of observations (eigenvalues of the covariance
#'   matrix relate to squared singular values of X by a factor of n-1).
#' @param k Rank of the approximation.
#' @return The theoretical minimum Frobenius reconstruction error.
eckart_young_bound <- function(eigenvalues, n_obs, k) {
  leftover_eigenvalues <- eigenvalues[-seq_len(k)]
  sqrt((n_obs - 1) * sum(leftover_eigenvalues))
}
