library(dplyr)
source("R/linalg_functions.R")

set.seed(42)

# Simulate correlated data: 200 observations, 5 variables, with a known
# correlation structure (a few variables share common underlying
# factors) so that the data has real, non-trivial principal components
# to find -- rather than being pure uncorrelated noise, which would
# give every direction roughly equal variance and make "which direction
# matters most" an uninteresting question.
n <- 200
factor1 <- rnorm(n)
factor2 <- rnorm(n)

X <- cbind(
  v1 = factor1 + rnorm(n, sd = 0.3),
  v2 = factor1 + rnorm(n, sd = 0.3),
  v3 = factor1 + factor2 + rnorm(n, sd = 0.3),
  v4 = factor2 + rnorm(n, sd = 0.3),
  v5 = rnorm(n, sd = 1.5)   # mostly independent noise variable
)

X_centered <- scale(X, center = TRUE, scale = FALSE)

cat("=== 1. PCA from scratch (power iteration + deflation) ===\n")
pca_scratch <- pca_from_scratch(X, k = ncol(X))
print(round(pca_scratch$eigenvalues, 4))

cat("\n=== 2. Cross-check against base R's eigen() on the same covariance matrix ===\n")
cov_matrix <- cov(X)
eigen_base <- eigen(cov_matrix, symmetric = TRUE)
print(round(eigen_base$values, 4))

eigenvalue_diff <- max(abs(pca_scratch$eigenvalues - eigen_base$values))
cat("Max absolute difference in eigenvalues (scratch vs. base R):", format(eigenvalue_diff, scientific = TRUE), "\n")

cat("\n=== 3. Cross-check against base R's prcomp() ===\n")
pca_base <- prcomp(X, center = TRUE, scale. = FALSE)
variance_diff <- max(abs(pca_scratch$variance_explained - (pca_base$sdev^2 / sum(pca_base$sdev^2))))
cat("Max absolute difference in variance explained (scratch vs. prcomp):", format(variance_diff, scientific = TRUE), "\n")

cat("\n=== 4. Rayleigh quotient bound check ===\n")
# The spectral theorem guarantees: for ANY nonzero x, the Rayleigh
# quotient R(x) = x'Ax / x'x lies between the smallest and largest
# eigenvalue of A. Sample many random x and confirm none ever violate
# that bound.
n_trials <- 2000
quotients <- replicate(n_trials, {
  x <- rnorm(ncol(X))
  rayleigh_quotient(cov_matrix, x)
})
lambda_min <- min(eigen_base$values)
lambda_max <- max(eigen_base$values)
violations <- sum(quotients < lambda_min - 1e-8 | quotients > lambda_max + 1e-8)
cat("Lambda_min:", round(lambda_min, 4), " Lambda_max:", round(lambda_max, 4), "\n")
cat("Rayleigh quotient range observed: [", round(min(quotients), 4), ",", round(max(quotients), 4), "]\n")
cat("Out-of-bound violations (should be 0):", violations, "out of", n_trials, "trials\n")

cat("\n=== 5. Eckart-Young theorem check ===\n")
# For each rank k, compare the ACTUAL reconstruction error from PCA
# against the THEORETICAL minimum possible error for any rank-k
# approximation -- Eckart-Young says these should match.
eckart_young_results <- lapply(1:4, function(k) {
  recon <- reconstruct_rank_k(X_centered, pca_scratch, k)
  bound <- eckart_young_bound(pca_scratch$eigenvalues, n, k)
  data.frame(k = k, actual_error = recon$frobenius_error, theoretical_bound = bound)
}) |> bind_rows()

print(eckart_young_results)

saveRDS(list(
  X = X, X_centered = X_centered,
  pca_scratch = pca_scratch, eigen_base = eigen_base, pca_base = pca_base,
  eigenvalue_diff = eigenvalue_diff, variance_diff = variance_diff,
  quotients = quotients, lambda_min = lambda_min, lambda_max = lambda_max, violations = violations,
  eckart_young_results = eckart_young_results
), "data/clean/verification_results.rds")
